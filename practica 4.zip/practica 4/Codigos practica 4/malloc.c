#include <stdio.h>
#include <stdlib.h>
int main (){
    //declaracion de varibles tipo apuntador y tradiccionales//
    int *arreglo, num, cont;
    //imprimir el numero de elementos que tiene el conjunto//
    printf("¿Cuantos elementos tiene el conjunto?\n");
    //guardar el dato de tipo entero en la variable num//
    scanf("%d",&num);
    //arreglo donde se integra la palabra malloc//
    arreglo = (int *)malloc (num * sizeof(int));
    //si no puede reservar el espacio de memoria nos regresa NULL//
    if (arreglo!=NULL) {
        //muestra el espacio de memoria reservada//
        printf("Vector reservado:\n\t[");
        for (cont=0 ; cont<num ; cont++){
            printf("\t%d",*(arreglo+cont));
        }
        //limpia el espacio reservado//
        printf("\t]\n");
        printf("Se libera el espacio reservado.\n");
        free(arreglo);
    }
    return 0;
}

