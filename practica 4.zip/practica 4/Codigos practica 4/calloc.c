#include <stdio.h>
#include <stdlib.h>
int main (){
    //variables tipo apuntador y tradicionales//
    int *arreglo, num, cont;
    //pedir el numero de elementos del conjunto, estos deben ser tipo entero//
    printf("¿Cuantos elementos tiene el conjunto?\n");
    scanf("%d",&num);
    arreglo = (int *)calloc (num, sizeof(int));
    //regresa NULL si no se puede reservar el espacio de memoria//
    if (arreglo!=NULL) {
    //muestra el espacio reservado//
        printf("Vector reservado:\n\t[");
        for (cont=0 ; cont<num ; cont++){
            printf("\t%d",*(arreglo+cont));
        }
        //libera memoria//
        printf("\t]\n");
        printf("Se libera el espacio reservado.\n");
        free(arreglo);
    }
    return 0;
}

